/**
 * Created by Rashed on 10/09/2015.
 */
var tally = 2;
$(document).ready(function(){
    setInterval(function() {tabScroller()}, 3000);

    $('.social-icons').children("i").mouseenter(function(){
        $(this).css("font-size", "1.2em");
    });

    $('.social-icons').children("i").mouseleave(function(){
        $(this).css("font-size", "1em");
    })
});


function tabScroller()
{
    $('#news-' + tally).click();
    tally++;
    if(tally == 6) tally = 1;

}


