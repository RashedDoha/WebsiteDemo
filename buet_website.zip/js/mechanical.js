/**
 * Created by Rashed on 10/09/2015.
 */

$(document).ready(function(){
    $('#header').show('slide', {direction: 'left'}, 1000);
});
